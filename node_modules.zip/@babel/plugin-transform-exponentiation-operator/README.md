# @babel/plugin-transform-exponentiation-operator

> Compile exponentiation operator to ES5

See our website [@babel/plugin-transform-exponentiation-operator](https://babeljs.io/docs/babel-plugin-transform-exponentiation-operator) for more information.

## Install

Using npm:

```sh
npm install --save-dev @babel/plugin-transform-exponentiation-operator
```

or using yarn:

```sh
yarn add @babel/plugin-transform-exponentiation-operator --dev
```
